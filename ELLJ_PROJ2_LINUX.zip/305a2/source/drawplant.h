/* Functions implemented in drawplant.h */

void drawPlant(void);
void drawBranch(void);
void drawLeaf(void);
